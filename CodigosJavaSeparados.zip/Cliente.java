package br.edu.ifpi.Model;

public class Cliente extends UsuarioAutenticavel {
    // Atributos específicos do Cliente podem ser adicionados aqui
}