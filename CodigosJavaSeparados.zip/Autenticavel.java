package br.edu.ifpi.Model;

public interface Autenticavel {
    boolean autenticar(String senha);
}